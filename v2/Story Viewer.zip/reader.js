/* ============================================================
   STORY READER — front-end prototype
   Handles: pagination, navigation, library, TOC, bookmarks,
   preferences, tweaks, keyboard + wheel, progress.
============================================================ */

// ---------- SAMPLE LIBRARY ----------
const LIBRARY = [
  {
    id: 'cartographer',
    title: 'The Cartographer of Lost Things',
    author: 'Elena Varga',
    pages: 284,
    progress: 0.11,
    current: true,
    chapters: [
      { num: 'I',   title: 'The Lantern',           start: 1 },
      { num: 'II',  title: 'A Map Without Borders', start: 6 },
      { num: 'III', title: 'The Salt Road',         start: 11 },
      { num: 'IV',  title: 'What the Birds Knew',   start: 17 },
      { num: 'V',   title: 'The Cartographer',      start: 23 }
    ],
    content: [
      { type: 'chapter', num: 'I', title: 'The Lantern',
        text: `It was the night of the long rain, and the small brass lantern in the window of the harbormaster's cottage had been burning, uninterrupted, for three days. Mira had counted. She counted many things in those years — the stones on the seawall, the hours between her father's letters, the cracks in the ceiling that, if you tilted your head a certain way, began to look like a map of somewhere that did not exist.

The lantern had been her mother's, and before that her mother's mother's, who had come to the island on a ship whose name no one remembered because she had refused to speak of it. Mira's grandmother had once told her that a lantern was a kind of promise, and that as long as one burned, a person was not yet lost.

"Not lost to themselves," she had said, more quietly, "which is the only kind of lost that matters."

Mira was sixteen the night the rain did not stop. She had been working, by the lantern's narrow light, on a map of her own — a map of the places she had not yet been. It was not like other maps. It had no scale. It had no north. Instead it was a rumor of a country, half-remembered from the stories her grandmother had told, stitched together from a child's certainty that the world was wider than the harbor and more tender than it pretended to be.`
      },
      { type: 'body',
        text: `She drew carefully, in ink the color of wet stones. A coastline that curled back on itself like a sleeping animal. A mountain with a name she had invented: the Mountain of Small Returns. A forest whose trees, she had decided, each kept a single secret, and would whisper it to anyone brave enough to stand perfectly still for a full day.

The rain made a sound against the windows that was almost like voices. Almost. If you had been very tired, or very lonely, or sixteen on an island in autumn, you might have mistaken it for someone calling your name.

Mira paused, her pen hovering. She listened. Beyond the window there was only the wet, black shape of the sea, and the thin amber thread of the lantern reflected back at her. She bent to the page again.

It was then that she heard the knock.`
      },
      { type: 'body',
        text: `Three times, not quick — the careful, patient knock of someone who knows perfectly well that the people inside are awake. Mira set down her pen. She was alone; her father had gone to the mainland for the month, as he did every autumn, to sell the year's salt and to buy, in secret, the blue sugar candies that he pretended to discover each December. She was not afraid. Or she was afraid, but only slightly, and in a way that she had already decided would not stop her.

She crossed the narrow room and opened the door.

A man stood on the porch, streaming with rain. He wore a long coat the color of a bruise, and carried, in one gloved hand, a leather case that had been patched, and patched again, until the original leather was mostly a memory. He was not young. He was not old. His eyes, in the lantern light, were the color of the sea in the hour before a storm.

"Good evening," he said, as though arriving at a tea party. "I am told there is, somewhere in this house, a girl who has been drawing maps of places that do not exist."`
      },
      { type: 'dialogue',
        text: `"Who told you that?" Mira asked.

"A bird," the man said. "Several birds, in fact. They have been complaining about it for weeks."

She stared at him. The rain, which had seemed to her a moment before to be only rain, now felt like a curtain being drawn back.

"My name is Auster," the man said. "I am a cartographer — though, you will forgive me, not of the usual sort." He tilted his head, rainwater running off the brim of his hat. "I wonder if I might come in. I have come rather a long way, and I find I am, as the saying goes, dripping."`
      },
      { type: 'body',
        text: `Mira, who had been raised by her grandmother to let strangers in out of the rain even when her better sense told her not to, stepped aside. Auster entered, dripping precisely as promised, and set his leather case down by the stove with the tenderness of a man putting down a sleeping child.

He looked around the small, warm room. He looked at the maps pinned to every wall — her father's navigational charts, faded and smudged by salt. He looked at the lantern in the window. He looked, finally, at the half-finished page on Mira's desk, the coastline curling in on itself, the Mountain of Small Returns, the forest of patient trees.

"Ah," he said softly. "Yes. Yes, this will do."`
      },

      { type: 'chapter', num: 'II', title: 'A Map Without Borders',
        text: `In the morning, which arrived reluctantly and grey, Mira found Auster asleep in the chair by the stove, the leather case open on the floor beside him. She did not mean to look into it. She looked into it.

Inside, instead of maps, there were letters. Hundreds of them, bound with ribbons of every color, each ribbon — she would learn later — belonging to a person who had once been lost and was now, by the slow, stubborn arithmetic of hope, a little less so.

"It is rude," Auster said, without opening his eyes, "to read another man's correspondence."

"I wasn't reading," said Mira, who had been reading.

"I'll allow it," he said, "this once. Since you are going to be my apprentice."`
      },
      { type: 'dialogue',
        text: `"I am not," Mira said, "your apprentice."

"Not yet." Auster opened one eye. It was the color, this morning, of weak tea. "But you will be, I think. You are already halfway there. The other half is paperwork."

"I don't know how to make maps."

"Ah," he said. "Then you are perfectly qualified. The people who know how to make maps are hopeless at it. They are always trying to put the world into a rectangle. The world does not wish to be in a rectangle. The world wishes to be in a spiral, or perhaps a bowl of soup."

Mira, despite herself, laughed.`
      },
      { type: 'body',
        text: `He taught her, that winter, a kind of cartography she had not known was possible. He taught her that a map is not a picture of a place but a promise to someone who is looking. He taught her that every coastline is a story about where the land changed its mind, and that every mountain is an argument between the earth and the sky, and that every forest is a committee of trees who have decided, over centuries, to agree on almost nothing except that they will stand together anyway.

"A map," he said, on a night when the stove had gone out and neither of them had noticed, "is how we tell someone, you are not the first. Someone has walked here before you. Someone will walk here after. You are part of a long, quiet procession, and the road, though it forgets your footsteps, does not forget that you came."`
      }
    ]
  },
  { id: 'greenfield', title: 'Notes from Greenfield',         author: 'Tomás Arroyo', pages: 142, progress: 0.47 },
  { id: 'seventh',    title: 'The Seventh Letter',            author: 'Ines Moreau',  pages: 98,  progress: 1.0  },
  { id: 'hollow',     title: 'A Small Hollow in the Evening', author: 'Kai Otsuka',   pages: 210, progress: 0.0  },
  { id: 'ledger',     title: "The Ledger of Uncommon Hours",  author: 'R. Finch',     pages: 318, progress: 0.22 }
];

// ---------- STATE ----------
const state = {
  currentBookId: 'cartographer',
  currentPage: 1,
  totalPages: 0,
  pages: [],     // [{ html, chapterIdx }]
  bookmarks: [
    { bookId: 'cartographer', title: 'The Cartographer of Lost Things', page: 3, date: 'Apr 14 · 9:32 pm' },
    { bookId: 'greenfield',   title: 'Notes from Greenfield',           page: 67, date: 'Apr 12 · 7:04 am' },
    { bookId: 'seventh',      title: 'The Seventh Letter',              page: 98, date: 'Apr 09 · 11:51 pm' }
  ]
};

// ---------- UTIL ----------
const qs = s => document.querySelector(s);
const qsa = s => document.querySelectorAll(s);

function toast(text, icon = 'bookmark') {
  qs('#toast-text').textContent = text;
  qs('#toast').classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => qs('#toast').classList.remove('show'), 1800);
}

// ---------- PAGINATION ----------
// Characters-per-page mirrors the Python app (~1050 chars) but shifts with tweaks.
function charsPerPage() {
  const cs = getComputedStyle(document.documentElement);
  const fs = parseFloat(cs.getPropertyValue('--body-size'));
  const lh = parseFloat(cs.getPropertyValue('--body-leading'));
  const mx = parseFloat(cs.getPropertyValue('--page-margin-x'));
  const mw = parseFloat(cs.getPropertyValue('--page-max-width'));
  const py = parseFloat(cs.getPropertyValue('--page-margin-y'));

  // Rough character area: width-in-chars * lines-per-page
  const charsPerLine = Math.max(28, Math.floor(mw / (fs * 0.48)));
  const availH = (window.innerHeight - 56 - 48) - py * 2; // canvas minus top/progress
  const lineH = fs * lh;
  const lines = Math.max(8, Math.floor(availH / lineH));
  return Math.floor(charsPerLine * lines * 0.92);
}

function splitIntoPages(book) {
  const pages = [];
  const cap = charsPerPage();

  book.content.forEach((block, bIdx) => {
    // Chapter openings always start a new page, taking the chapter head
    // plus a chunk of body text.
    const paragraphs = block.text.split(/\n\n+/).map(p => p.trim()).filter(Boolean);

    if (block.type === 'chapter') {
      // Build first page of the chapter with kicker + chapter title + intro
      let head =
        `<div class="chapter-kicker">Chapter ${block.num}</div>` +
        `<h1>${block.title}</h1>`;
      // find chapterIdx in book.chapters by title match
      const chapterIdx = book.chapters.findIndex(c => c.title === block.title);
      let body = '';
      let first = true;
      for (const p of paragraphs) {
        const add = `<p class="${first ? 'dropcap no-indent' : ''}">${p}</p>`;
        if ((head + body + add).length > cap && body.length > 0) {
          pages.push({ html: head + body, chapterIdx });
          head = ''; body = add;
        } else {
          body += add;
          first = false;
        }
      }
      if (body) pages.push({ html: head + body, chapterIdx });
    } else {
      // Continue in the current chapter
      const chapterIdx = pages.length ? pages[pages.length - 1].chapterIdx : 0;
      let buf = '';
      for (const p of paragraphs) {
        const add = `<p${block.type === 'dialogue' ? ' class="no-indent"' : ''}>${p}</p>`;
        if (buf.length + add.length > cap && buf.length > 0) {
          pages.push({ html: buf, chapterIdx });
          buf = add;
        } else {
          buf += add;
        }
      }
      if (buf) pages.push({ html: buf, chapterIdx });
    }
  });

  // Pad to make the book feel longer (demo only) — replicate last body blocks
  // so TOC/progress markers feel meaningful.
  return pages;
}

// ---------- RENDER ----------
function renderLibrary() {
  const el = qs('#library');
  el.innerHTML = LIBRARY.map(b => {
    const active = b.id === state.currentBookId;
    const pct = Math.round((b.progress || 0) * 100);
    const statusText = pct === 100 ? 'Finished' : pct === 0 ? 'Unread' : `${pct}% · p${Math.max(1, Math.round((b.progress||0) * b.pages))}`;
    // Fake spine color per book
    const hues = { cartographer: '#5a2018', greenfield: '#2d4a30', seventh: '#3a2f15', hollow: '#1f2e3f', ledger: '#4a2844' };
    return `
      <div class="book-item ${active ? 'active' : ''}" data-id="${b.id}">
        <div class="book-spine" style="background-color:${hues[b.id] || '#3a2f21'}"></div>
        <div class="book-info">
          <div class="book-title">${b.title}</div>
          <div class="book-meta">${b.author.toUpperCase()} · ${statusText}</div>
        </div>
        <div class="book-dot"></div>
      </div>
    `;
  }).join('');

  el.querySelectorAll('.book-item').forEach(node => {
    node.addEventListener('click', () => {
      const id = node.dataset.id;
      if (id === state.currentBookId) return;
      const book = LIBRARY.find(b => b.id === id);
      if (!book || !book.content) {
        toast(`"${book?.title || 'Book'}" — sample only`, 'info');
        return;
      }
      loadBook(id);
    });
  });
}

function renderTOC() {
  const book = LIBRARY.find(b => b.id === state.currentBookId);
  const el = qs('#toc');
  if (!book || !book.chapters) { el.innerHTML = ''; return; }
  const currentChapter = state.pages[state.currentPage - 1]?.chapterIdx ?? 0;
  el.innerHTML = book.chapters.map((c, i) => `
    <div class="toc-item ${i === currentChapter ? 'current' : ''}" data-chapter="${i}">
      <span>${c.title}</span>
      <span class="toc-num">${c.num}</span>
    </div>
  `).join('');
  el.querySelectorAll('.toc-item').forEach(node => {
    node.addEventListener('click', () => {
      const idx = +node.dataset.chapter;
      // jump to first page whose chapterIdx matches
      const pageIdx = state.pages.findIndex(p => p.chapterIdx === idx);
      if (pageIdx >= 0) showPage(pageIdx + 1);
    });
  });
}

function renderBookmarks() {
  const el = qs('#bm-list');
  if (!state.bookmarks.length) {
    el.innerHTML = '<div style="text-align:center; color: var(--cream-400); padding: 30px; font-style: italic;">No bookmarks yet. Press <strong style="color:var(--brass)">B</strong> while reading to leave a mark.</div>';
    return;
  }
  el.innerHTML = state.bookmarks.map((bm, i) => `
    <div class="bm-item" data-idx="${i}">
      <div class="bm-ribbon"></div>
      <div class="bm-info">
        <div class="bm-title">${bm.title}</div>
        <div class="bm-sub">${bm.date}</div>
      </div>
      <div class="bm-page">P. ${bm.page}</div>
      <button class="bm-del" title="Remove bookmark" data-del="${i}">
        <svg class="i-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
      </button>
    </div>
  `).join('');

  el.querySelectorAll('.bm-item').forEach(node => {
    node.addEventListener('click', (e) => {
      if (e.target.closest('[data-del]')) return;
      const idx = +node.dataset.idx;
      const bm = state.bookmarks[idx];
      if (bm.bookId === state.currentBookId) {
        showPage(bm.page);
      } else {
        if (LIBRARY.find(b => b.id === bm.bookId)?.content) {
          loadBook(bm.bookId, bm.page);
        } else {
          toast(`"${bm.title}" — sample only`);
        }
      }
      closeModal('modal-bookmarks');
    });
  });
  el.querySelectorAll('[data-del]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      state.bookmarks.splice(+btn.dataset.del, 1);
      renderBookmarks();
    });
  });
}

function renderChapterMarks() {
  const el = qs('#chapter-marks');
  const book = LIBRARY.find(b => b.id === state.currentBookId);
  if (!book || !book.chapters) { el.innerHTML = ''; return; }
  // mark where chapters begin as a percentage of pages
  el.innerHTML = state.pages.map((p, i) => {
    const prev = i > 0 ? state.pages[i - 1].chapterIdx : -1;
    if (p.chapterIdx !== prev && i > 0) {
      const pct = (i / (state.pages.length - 1)) * 100;
      return `<div class="chapter-mark" style="left:${pct}%" title="Ch ${book.chapters[p.chapterIdx]?.num}"></div>`;
    }
    return '';
  }).join('');
}

function renderPages() {
  const wrap = qs('#page-wrap');
  wrap.innerHTML = state.pages.map((p, i) =>
    `<div class="page ${i === state.currentPage - 1 ? 'active' : ''}" data-i="${i}">${p.html}</div>`
  ).join('');
}

function updateChrome() {
  const book = LIBRARY.find(b => b.id === state.currentBookId);
  const cur = state.currentPage;
  const tot = state.totalPages;
  const pageData = state.pages[cur - 1];
  const chapter = book.chapters[pageData?.chapterIdx ?? 0];

  qs('#crumb-chapter').textContent = chapter ? `Ch. ${chapter.num} · ${chapter.title}` : '';
  qs('#crumb-title').textContent = book.title;

  qs('#page-input').value = cur;
  qs('#total-pages').textContent = tot;
  qs('#p-cur').textContent = cur;
  qs('#p-tot').textContent = tot;
  qs('#p-chap').textContent = chapter ? chapter.num : '—';

  const pct = tot > 1 ? ((cur - 1) / (tot - 1)) * 100 : 0;
  qs('#progress-fill').style.width = pct + '%';
  qs('#progress-thumb').style.left = pct + '%';
  qs('#p-pct').textContent = Math.round(pct);

  // reading time estimate: 220 wpm, ~180 words/page
  const remPages = tot - cur;
  qs('#p-rem').textContent = Math.max(1, Math.round(remPages * 180 / 220));

  qs('#edge-prev').classList.toggle('disabled', cur <= 1);
  qs('#edge-next').classList.toggle('disabled', cur >= tot);

  renderTOC();
}

function showPage(n) {
  n = Math.max(1, Math.min(n, state.totalPages));
  if (n === state.currentPage) return;

  const pages = qsa('.page');
  const oldIdx = state.currentPage - 1;
  state.currentPage = n;
  pages.forEach(p => p.classList.remove('active'));
  const next = document.querySelector(`.page[data-i="${n - 1}"]`);
  if (next) next.classList.add('active');

  updateChrome();
}

// ---------- LOAD BOOK ----------
function loadBook(bookId, page = 1) {
  const book = LIBRARY.find(b => b.id === bookId);
  if (!book || !book.content) return;
  state.currentBookId = bookId;
  state.pages = splitIntoPages(book);
  state.totalPages = state.pages.length;
  state.currentPage = Math.min(Math.max(1, page), state.totalPages);
  renderPages();
  renderLibrary();
  renderChapterMarks();
  updateChrome();
}

// ---------- MODALS ----------
function openModal(id) {
  qs('#' + id).classList.add('open');
  if (id === 'modal-bookmarks') renderBookmarks();
}
function closeModal(id) {
  qs('#' + id).classList.remove('open');
}

// ---------- TWEAKS (persisted) ----------
function applyTweaks(t) {
  document.documentElement.style.setProperty('--body-size', t.bodySize + 'px');
  document.documentElement.style.setProperty('--body-leading', t.leading);
  document.documentElement.style.setProperty('--page-margin-x', t.pageMarginX + 'px');
  document.documentElement.style.setProperty('--page-max-width', t.pageMaxWidth + 'px');

  // Reflect on all slider UIs
  [['fs-slider','fs-val',t.bodySize,'px'], ['tw-fs','tw-fs-val',t.bodySize,'px']].forEach(([s,v,val,suf])=>{
    const sl = qs('#'+s), vl = qs('#'+v);
    if (sl) sl.value = val; if (vl) vl.textContent = val + suf;
  });
  [['lh-slider','lh-val',t.leading,''], ['tw-lh','tw-lh-val',t.leading,'']].forEach(([s,v,val,suf])=>{
    const sl = qs('#'+s), vl = qs('#'+v);
    if (sl) sl.value = val; if (vl) vl.textContent = (+val).toFixed(2) + suf;
  });
  [['mx-slider','mx-val',t.pageMarginX,'px'], ['tw-mx','tw-mx-val',t.pageMarginX,'px']].forEach(([s,v,val,suf])=>{
    const sl = qs('#'+s), vl = qs('#'+v);
    if (sl) sl.value = val; if (vl) vl.textContent = val + suf;
  });
  const mw = qs('#tw-mw'), mwv = qs('#tw-mw-val');
  if (mw) mw.value = t.pageMaxWidth;
  if (mwv) mwv.textContent = t.pageMaxWidth + 'px';
}

function persistTweaks(partial) {
  Object.assign(TWEAK_DEFAULTS, partial);
  try {
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: partial }, '*');
  } catch (_) {}
}

function onTweakChange(key, val) {
  persistTweaks({ [key]: val });
  applyTweaks(TWEAK_DEFAULTS);
  // Repaginate when layout-affecting tweak changes
  if (key === 'bodySize' || key === 'leading' || key === 'pageMarginX' || key === 'pageMaxWidth') {
    // Keep current page proportionally
    const pct = state.totalPages > 1 ? (state.currentPage - 1) / (state.totalPages - 1) : 0;
    loadBook(state.currentBookId, 1);
    const target = Math.round(pct * (state.totalPages - 1)) + 1;
    showPage(target);
  }
}

// ---------- WIRING ----------
function bindEvents() {
  // Sidebar collapse
  qs('#collapse-btn').addEventListener('click', () => {
    qs('#app').classList.toggle('collapsed');
  });

  // Rail buttons
  document.querySelectorAll('[data-rail]').forEach(btn => {
    btn.addEventListener('click', () => {
      qs('#app').classList.remove('collapsed');
      const target = btn.dataset.rail;
      if (target === 'bookmarks') openModal('modal-bookmarks');
      else if (target === 'settings') {
        // scroll settings section into view
        qs('#fs-slider').scrollIntoView({ block: 'center' });
      }
    });
  });

  // Top toolbar
  qs('#btn-prev5').addEventListener('click', () => showPage(state.currentPage - 5));
  qs('#btn-next5').addEventListener('click', () => showPage(state.currentPage + 5));
  qs('#btn-bookmark-page').addEventListener('click', () => {
    const book = LIBRARY.find(b => b.id === state.currentBookId);
    const existing = state.bookmarks.findIndex(b => b.bookId === state.currentBookId);
    if (existing >= 0) state.bookmarks.splice(existing, 1);
    state.bookmarks.unshift({
      bookId: state.currentBookId,
      title: book.title,
      page: state.currentPage,
      date: new Date().toLocaleString('en-US', { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' })
    });
    toast(`Bookmarked page ${state.currentPage}`);
  });
  qs('#btn-tweaks').addEventListener('click', () => {
    qs('#tweaks').classList.toggle('open');
  });
  qs('#tweaks-close').addEventListener('click', () => qs('#tweaks').classList.remove('open'));

  // Edge nav
  qs('#edge-prev').addEventListener('click', () => showPage(state.currentPage - 1));
  qs('#edge-next').addEventListener('click', () => showPage(state.currentPage + 1));

  // Page input
  qs('#page-input').addEventListener('change', e => {
    const n = parseInt(e.target.value, 10);
    if (!isNaN(n)) showPage(n);
  });
  qs('#page-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') { const n = parseInt(e.target.value, 10); if (!isNaN(n)) showPage(n); }
  });

  // Progress track scrubbing
  qs('#progress-track').addEventListener('click', (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const target = Math.round(pct * (state.totalPages - 1)) + 1;
    showPage(target);
  });

  // Sidebar footer buttons
  qs('#btn-bookmarks').addEventListener('click', () => openModal('modal-bookmarks'));
  qs('#btn-prefs').addEventListener('click', () => openModal('modal-prefs'));

  // Modal close
  document.querySelectorAll('[data-close]').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.closest('.modal-scrim').classList.remove('open');
    });
  });
  document.querySelectorAll('.modal-scrim').forEach(s => {
    s.addEventListener('click', e => { if (e.target === s) s.classList.remove('open'); });
  });

  // Prefs tabs
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      ['general','bindings','about'].forEach(id => {
        qs('#tab-' + id).style.display = id === tab.dataset.tab ? '' : 'none';
      });
    });
  });

  // Sidebar sliders
  qs('#fs-slider').addEventListener('input', e => onTweakChange('bodySize', +e.target.value));
  qs('#lh-slider').addEventListener('input', e => onTweakChange('leading', +e.target.value));
  qs('#mx-slider').addEventListener('input', e => onTweakChange('pageMarginX', +e.target.value));
  // Tweak sliders
  qs('#tw-fs').addEventListener('input', e => onTweakChange('bodySize', +e.target.value));
  qs('#tw-lh').addEventListener('input', e => onTweakChange('leading', +e.target.value));
  qs('#tw-mx').addEventListener('input', e => onTweakChange('pageMarginX', +e.target.value));
  qs('#tw-mw').addEventListener('input', e => onTweakChange('pageMaxWidth', +e.target.value));

  // Keyboard
  window.addEventListener('keydown', e => {
    if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA') return;
    if (document.querySelector('.modal-scrim.open')) {
      if (e.key === 'Escape') document.querySelectorAll('.modal-scrim.open').forEach(m => m.classList.remove('open'));
      return;
    }
    switch (e.key) {
      case 'ArrowRight': case ' ': case 'PageDown': showPage(state.currentPage + 1); e.preventDefault(); break;
      case 'ArrowLeft': case 'PageUp': showPage(state.currentPage - 1); e.preventDefault(); break;
      case 'ArrowDown': showPage(state.currentPage + 5); e.preventDefault(); break;
      case 'ArrowUp':   showPage(state.currentPage - 5); e.preventDefault(); break;
      case 'Home': showPage(1); break;
      case 'End':  showPage(state.totalPages); break;
      case 'b': case 'B': qs('#btn-bookmark-page').click(); break;
      case '[': qs('#app').classList.toggle('collapsed'); break;
    }
  });

  // Mouse wheel over canvas
  qs('.canvas').addEventListener('wheel', e => {
    if (Math.abs(e.deltaY) < 15) return;
    e.preventDefault();
    showPage(state.currentPage + (e.deltaY > 0 ? 1 : -1));
  }, { passive: false });

  // Tweaks protocol (host toolbar toggle)
  window.addEventListener('message', e => {
    const t = e.data?.type;
    if (t === '__activate_edit_mode') qs('#tweaks').classList.add('open');
    else if (t === '__deactivate_edit_mode') qs('#tweaks').classList.remove('open');
  });
  try { window.parent.postMessage({ type: '__edit_mode_available' }, '*'); } catch (_) {}

  // Repaginate on resize (debounced)
  let rt;
  window.addEventListener('resize', () => {
    clearTimeout(rt);
    rt = setTimeout(() => {
      const pct = state.totalPages > 1 ? (state.currentPage - 1) / (state.totalPages - 1) : 0;
      loadBook(state.currentBookId, 1);
      showPage(Math.round(pct * (state.totalPages - 1)) + 1);
    }, 220);
  });
}

// ---------- BOOT ----------
function boot() {
  applyTweaks(TWEAK_DEFAULTS);
  loadBook('cartographer', 1);
  bindEvents();
}
boot();
